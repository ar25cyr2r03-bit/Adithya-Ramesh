import json
import streamlit as st
from rule_engine import analyze

st.set_page_config(page_title="Electrochemical Compatibility Screener", page_icon="⚗️", layout="wide")
st.title("⚗️ Electrochemical Compatibility Screener")
st.caption("Qualitative amino-acid / metal / electrolyte screening using the supplied rule engine.")

st.warning(
    "Research screening aid only. Results are qualitative, depend on the uploaded catalog, "
    "and require experimental and safety confirmation. Do not use this tool as authorization to mix chemicals."
)

st.markdown("### 1. Upload the input data")
st.write("Upload two JSON files: one catalog and one reaction list. The catalog must contain "
         "`amino_acids`, `metals`, `electrolytes`, and `conductor_comparisons`.")

catalog_file = st.file_uploader("Catalog JSON", type=["json"], key="catalog")
reaction_file = st.file_uploader("Reactions JSON", type=["json"], key="reactions")

def read_json(upload):
    try:
        return json.load(upload)
    except Exception as exc:
        st.error(f"Could not read JSON: {exc}")
        return None

catalog = read_json(catalog_file) if catalog_file else None
reactions = read_json(reaction_file) if reaction_file else None

if catalog is not None:
    required = ["amino_acids", "metals", "electrolytes", "conductor_comparisons"]
    missing = [key for key in required if key not in catalog]
    if missing:
        st.error("Catalog is missing required top-level keys: " + ", ".join(missing))
        catalog = None

if reactions is not None and not isinstance(reactions, list):
    st.error("Reaction JSON must be a JSON array of reaction objects.")
    reactions = None

if catalog:
    st.success("Catalog loaded.")
    st.markdown("### 2. Choose the screening conditions")
    col1, col2, col3 = st.columns(3)

    def options(group):
        return {item["id"]: item.get("name", item["id"]) for item in catalog.get(group, [])}

    aa_options = options("amino_acids")
    metal_options = options("metals")
    electrolyte_options = options("electrolytes")

    with col1:
        aa_id = st.selectbox("Amino acid", list(aa_options), format_func=lambda x: aa_options[x])
    with col2:
        metal_id = st.selectbox("Metal", list(metal_options), format_func=lambda x: metal_options[x])
    with col3:
        electrolyte_id = st.selectbox("Electrolyte", list(electrolyte_options), format_func=lambda x: electrolyte_options[x])

    col4, col5 = st.columns(2)
    with col4:
        concentration = st.number_input("Concentration (M)", min_value=0.0, value=0.1, step=0.1, format="%.4f")
    with col5:
        ph_entry = st.text_input("pH (optional)", placeholder="Leave blank if not supplied")

    if st.button("Run screening", type="primary", disabled=(not reactions)):
        payload = {
            "amino_acid": aa_id,
            "metal": metal_id,
            "electrolyte": electrolyte_id,
            "concentration_m": concentration,
        }
        if ph_entry.strip():
            try:
                payload["ph"] = float(ph_entry)
            except ValueError:
                st.error("Enter pH as a number, or leave it blank.")
                st.stop()

        try:
            result = analyze(payload, catalog, reactions)
            st.markdown("## Screening result")
            st.subheader(result["summary"])
            st.metric("Compatibility flag", result["compatibility"]["rating"])
            st.write("**Coordination assessment:**", result["coordination"]["assessment"])
            st.write("**Geometry:**", result["coordination"]["geometry"])
            st.write("**Donor atoms:**", ", ".join(result["coordination"]["donor_atoms"]) or "None matched")
            st.write("**Coordination confidence:**", result["coordination"]["confidence"])

            st.markdown("### Electrochemical classification")
            electro = result["electrochemical"]
            st.write(f"**Class:** {electro['label']} · **Confidence:** {electro['confidence']} · **Score:** {electro['score']}")
            if electro["caveats"]:
                for item in electro["caveats"]:
                    st.write("• " + item)

            st.markdown("### Safety warnings")
            for item in result["safety_warnings"]:
                st.write("⚠️ " + item)

            st.markdown("### Catalyst screening")
            for item in result["catalyst_screening"]:
                st.write(f"**{item['name']}** — {item['note']}  \nSource: {item['source']}")

            st.markdown("### Conductor / dopant information")
            st.json(result["conductor_dopant"])

            st.markdown("### Suggested procedure")
            for i, item in enumerate(result["procedure"], 1):
                st.write(f"{i}. {item}")

            st.markdown("### Assumptions and limitations")
            for item in result["assumptions"]:
                st.write("• " + item)

            st.download_button(
                "Download result as JSON",
                data=json.dumps(result, indent=2, ensure_ascii=False),
                file_name="screening_result.json",
                mime="application/json",
            )
        except Exception as exc:
            st.error(f"Screening could not be completed: {exc}")
            st.info("Check that every selected ID exists in its catalog group and that required metadata fields are present.")
else:
    st.info("Upload a valid catalog JSON to populate the selectors.")

if not reactions:
    st.info("Upload a reactions JSON array to enable the screening button.")
