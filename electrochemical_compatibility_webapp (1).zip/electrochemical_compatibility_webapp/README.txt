ELECTROCHEMICAL COMPATIBILITY SCREENER — WEB APP

Contents
- app.py: Streamlit web interface
- rule_engine.py: your supplied rule engine (kept unchanged)
- requirements.txt: Python dependency

Run locally
1. Install Python 3.10+.
2. In a terminal, change into this folder.
3. Run: pip install -r requirements.txt
4. Run: streamlit run app.py
5. Streamlit will show a local URL in your browser.

Deploy publicly (Streamlit Community Cloud)
1. Create a GitHub repository and upload app.py, rule_engine.py, and requirements.txt.
2. Open https://share.streamlit.io/ and sign in.
3. Choose the repository, branch, and app.py as the main file.
4. Deploy. Streamlit will provide a public URL you can share.

IMPORTANT DATA REQUIREMENTS
The supplied Python file only defines the rule engine. It does not include the actual catalog or reaction records.
At runtime, upload:
- Catalog JSON object with top-level keys:
  amino_acids: array of objects with at least id, name, donor_atoms
  metals: array of objects with at least id, name, tags, preferred_donors
  electrolytes: array of objects with at least id, name, tags, conductor, dopant_effect
  conductor_comparisons: array or object as expected by your dataset
- Reactions JSON array. Each object should include compatible_metals (array of metal IDs), name, note, source.

The app intentionally does not fabricate missing scientific catalog data. The result is qualitative and not a substitute for SDS review, risk assessment, or experimental confirmation.
