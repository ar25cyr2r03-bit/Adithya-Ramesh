"""Small, auditable rule engine. Every conclusion includes evidence and caveats."""
from typing import Any


def _find(catalog, group, key):
    for item in catalog[group]:
        if item["id"] == key:
            return item
    raise KeyError(f"Unknown {group[:-1]}: {key}")


def _confidence(score):
    return "high" if score >= 0.8 else "moderate" if score >= 0.55 else "low"


def classify(electrolyte, metal, concentration):
    tags = set(electrolyte.get("tags", [])) | set(metal.get("tags", []))
    notes = []
    if "oxidizer" in tags and "reductant" in tags:
        label, score = "redox-active", 0.86
        notes.append("Both oxidizing and reducing flags are present; speciation and potential are unknown.")
    elif "redox-active-metal" in tags and ("oxidizer" in tags or "reductant" in tags):
        label, score = "redox-active", 0.8
        notes.append("A redox-active metal is paired with a redox-tagged electrolyte; electron-transfer pathways are plausible but unquantified.")
    elif "oxidizer" in tags:
        label, score = "oxidizing", 0.78
    elif "reductant" in tags:
        label, score = "reducing", 0.78
    elif "redox-active-metal" in tags:
        label, score = "redox-active", 0.68
    else:
        label, score = "inert", 0.58
        notes.append("Inert means no strong redox flag in this seed catalog, not electrochemical inactivity.")
    if concentration > 1.0:
        score -= 0.08
        notes.append("High concentration can change activity coefficients, conductivity, and side-reaction rates.")
    return {"label": label, "confidence": _confidence(score), "score": round(max(score, 0), 2), "caveats": notes}


def analyze(payload: dict[str, Any], catalog, reactions):
    aa = _find(catalog, "amino_acids", payload["amino_acid"])
    metal = _find(catalog, "metals", payload["metal"])
    electrolyte = _find(catalog, "electrolytes", payload["electrolyte"])
    concentration = float(payload.get("concentration_m", 0))
    if concentration < 0:
        raise ValueError("concentration_m must be non-negative")
    ph = payload.get("ph")
    assumptions = [
        "Aqueous, room-temperature screening; no competing ligands or precipitating anions modelled.",
        "Formal oxidation states and protonation states are inferred from catalog metadata.",
        "Predictions are qualitative and must be confirmed by spectroscopy, pH control, and electrochemical measurements.",
    ]
    donors = [d for d in aa["donor_atoms"] if d in metal["preferred_donors"]]
    coordination = "likely chelating" if len(donors) >= 2 else "likely monodentate or weakly associated"
    if "carboxylate" in donors and "amine" in donors:
        geometry = "amino-acid N,O chelate; geometry likely octahedral or distorted tetrahedral depending on metal"
    elif donors:
        geometry = f"coordination through {', '.join(donors)}; geometry unresolved"
    else:
        geometry = "no strong matching donor in the seed rules; complexation may be weak or require pH adjustment"
    risks = []
    if "toxic-heavy-metal" in metal["tags"]:
        risks.append("Heavy-metal exposure and waste hazard: use a fume hood, secondary containment, and approved waste stream.")
    if "oxidizer" in electrolyte["tags"] or "oxidizer" in metal["tags"]:
        risks.append("Oxidizer flag: keep away from organics/reducing agents and assess heat/gas evolution before mixing.")
    if "reductant" in electrolyte["tags"]:
        risks.append("Reducing electrolyte may consume dissolved oxygen or metal ions and alter speciation.")
    if "corrosive" in electrolyte["tags"] or "corrosive-salt" in metal["tags"]:
        risks.append("Corrosive flag: use compatible gloves, eye/face protection, secondary containment, and a reviewed dilution plan.")
    if "strong-base" in electrolyte["tags"] or "strong-acid" in electrolyte["tags"]:
        risks.append("Strong acid/base flag: pH, heat of dilution, corrosion, and rapid speciation changes are not quantitatively modelled.")
    if "moisture-sensitive" in electrolyte["tags"]:
        risks.append("Moisture-sensitive electrolyte: use a validated dry-atmosphere and waste procedure.")
    if "radioactive-material" in metal["tags"]:
        risks.append("Radioactive-material flag: do not use without licensed facilities, radiation controls, and specialist approval.")
    if concentration > 1:
        risks.append("Concentration exceeds the conservative 1 M screening threshold; check solubility, heat, and corrosion.")
    if not risks:
        risks.append("No seed-rule hazard trigger; still review current SDS, incompatibilities, and institutional controls.")
    compatibility = "conditional"
    if any(trigger in " ".join(risks).lower() for trigger in ("oxidizer", "heavy-metal", "corrosive", "radioactive", "strong acid/base")):
        compatibility = "do-not-mix-without-review"
    reaction_notes = []
    for reaction in reactions:
        if metal["id"] in reaction.get("compatible_metals", []):
            reaction_notes.append({"name": reaction["name"], "note": reaction["note"], "source": reaction["source"]})
    procedure = [
        "Optimization target: minimize exposure and uncertainty while preserving measurable observations; validate each change experimentally.",
        "Confirm identity, purity, SDS, and waste route; prepare a small-scale risk assessment.",
        f"Prepare {concentration:g} M {electrolyte['name']} using compatible materials and calibrated balance.",
        "Adjust pH only with a validated, dilute titrant while monitoring temperature and precipitation.",
        f"Add {aa['name']} before metal salt slowly under stirring; observe colour, turbidity, and temperature.",
        "Record pH, conductivity, visual observations, and (if available) UV-Vis/IR and cyclic voltammetry.",
        "Stop if gas, rapid heating, unexpected precipitate, or strong odour appears; isolate and consult safety staff.",
    ]
    return {
        "summary": f"{aa['name']} + {metal['name']} in {electrolyte['name']}",
        "coordination": {"assessment": coordination, "geometry": geometry, "donor_atoms": donors,
                         "confidence": _confidence(0.62 if donors else 0.35)},
        "compatibility": {"rating": compatibility, "concentration_m": concentration,
                          "rules": [f"electrolyte tags={electrolyte.get('tags', [])}",
                                    f"metal tags={metal.get('tags', [])}"]},
        "electrochemical": classify(electrolyte, metal, concentration),
        "safety_warnings": risks,
        "catalyst_screening": reaction_notes or [{"name": "No matching seed reaction", "note": "Do not infer catalytic activity from coordination alone.", "source": "MVP rule engine"}],
        "conductor_dopant": {"conductor": electrolyte["conductor"], "dopant_effect": electrolyte["dopant_effect"],
                             "comparison": catalog["conductor_comparisons"]},
        "procedure": procedure,
        "assumptions": assumptions + ([f"User supplied pH={ph}; pH effects are not quantitatively modelled."] if ph is not None else []),
        "requires_confirmation": True,
    }
